package argument_passing;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rownak
 */
class Test { 
  void meth(int i, int j) { 
    i *= 2; 
    j /= 2; 
  }  
}